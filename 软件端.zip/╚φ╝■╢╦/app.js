//app.js

const recycleBinMgr = require('utils/recycleBinManager.js')
const adMgr = require('utils/adManager.js')
const flagMgr = require('utils/flagManager.js');

App({
  onLaunch: function(options) {
    recycleBinMgr.washRecycleBin();
    flagMgr.update();
    this.globalData.adOptions = adMgr.getOptions();
  },
  
  globalData: {
    isInShareScene: false,
    adOptions: undefined,
  }
})