class enumItemDetail {
  constructor(value, displayName) {
    this.value = value;
    this.displayName = displayName;
  }
}
module.exports = {
  enumItemDetail: enumItemDetail,
}