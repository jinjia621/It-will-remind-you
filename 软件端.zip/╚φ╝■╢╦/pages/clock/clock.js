// 在需要使用的js文件中，导入js  
var util = require('../../utils/util.js');
var app=getApp()
Page({
  data: {
    date: '年-月-日',
    time1: '分-秒',
    now: '',
    status: "关",
    time3:''
  },
  clock:function(e){
    var that = this;
    var times = 0
    var a=that.data.time3
    var i = setInterval(function () {
      times++
      if (times >= a*60) {

        if(times>=a*60+1){
         wx.navigateTo({
           url: '/pages/ring/ring',
         })
        clearInterval(i)
        }
      }
    }, 1000)
    wx.showToast({
      title: '设置中',
      duration: 500,
      icon: 'loading'
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */

  onLoad: function (options) {
    console.log(options)
    // 调用函数时，传入new Date()参数，返回值是日期和时间  
    var time = util.formatTime(new Date());
    // 再通过setData更改Page()里面的data，动态更新页面的数据  
    this.setData({
      time: time
    });
  },
  /**
   * 页面的初始数据
   */
changeDate:function(e){
this.setData({
  date:e.detail.value
})
},
  changeTime: function (e) {
    this.setData({
      time1: e.detail.value
    })
  },
  changeTime2: function (e) {
    if (e.detail.value != "") {
      this.setData({
        time3: e.detail.value,
      })
    }
  },
change:function(){
  wx.showToast({
    title: '更改成功',
    duration:1000,
    icon:'success'
  })
  this.setData({
    date:this.data.date,
    time1: this.data.time1
  })
  this.sendRequset(this.makeObj(this.data.date,this.data.status, this.data.time1, "")); 
},
  show: function () {
    this.data.status = ((this.data.status == "0") ? "1" : "0"),
      this.setData({
        status: this.data.status
      })
    wx.showToast({
      title: this.data.status,
      duration: 1000
    })
    this.sendRequset(this.makeObj(this.data.date,this.data.status, this.data.time1, ""));
  },
toEgg:function(e){
  wx.navigateTo({
    url: '/pages/egg/egg',
  })
},




  sendRequset: function (obj) {
    wx.request(obj);
  },
  makeObj: function (d, t, sta,ret) {
    var obj = {
       url: "http://api.heclouds.com/devices/562371601/datapoints?type=3", 

      header: {
        "Content-Type": "application/json",
        "api-key": "we1j=61SRUDpIJ0DpJINNY6A18E=",
      },
      method: "post",
      data: {
    
        "date": d,
        "status": sta,
        "time1": t,
       
       },
      success: function (res) {
        if (ret != "") {
          wx.showToast({
            title: ret,
            duration: 2000
          })

        }
      }
    }
    return obj;
  },
  get_data: function () {
    // 获取数据
    var that = this;
    wx.request({
      url: 'http://api.heclouds.com/devices/562371601/datapoints?datastream_id=date,status,time1&limit=1',
      
      header: {
        'content-type': 'application/json',
        'api-key': 'we1j=61SRUDpIJ0DpJINNY6A18E='
      },

      success: function (res) {
        console.log(res.data)
        wx.showToast({
          title: "OK",
          duration: 1000
        })
      }
      })
  },







  

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  var bgm=app.bgm;
  this.setData({
    bgm:bgm
  })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
});