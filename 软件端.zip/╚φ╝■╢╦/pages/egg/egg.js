// pages/main/main.js
var app=getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
   
  },
  music2: function () {
    var that=this
    app.bgm='默认'
    app.i='1'
    wx.showToast({
      title: '设置成功',
      duration: 1000,
      icon: 'success'
    })
  },
  music1: function () {
   app.bgm='Hall of Fame'
   app.i='2'
    wx.showToast({
      title: '设置成功',
      duration: 1000,
      icon: 'success'
    })
  },
  music3: function () {
    app.bgm = 'The Phoenix'
    app.i='3'
    wx.showToast({
      title: '设置成功',
      duration: 1000,
      icon: 'success'
    })
  },
  music4: function () {
    app.bgm = 'Rise'
    app.i='4'
    wx.showToast({
      title: '设置成功',
      duration: 1000,
      icon: 'success'
    })
  },
  music5: function () {
    app.bgm = '追梦赤子心'
    app.i='5'
    wx.showToast({
      title: '设置成功',
      duration: 1000,
      icon: 'success'
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
   
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})