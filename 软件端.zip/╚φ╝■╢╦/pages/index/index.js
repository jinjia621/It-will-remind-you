const eventUtil = require('../../utils/eventUtil.js');
const mdEventLoop = require('../../models/eventLoopMode.js');
const util = require('../../utils/util.js');
const mdEventType = require('../../models/eventType.js');

//index.js
//获取应用实例
const app = getApp();


Page({
  data: {
    isSideSlipOpned: false,
   
    events: [],
    // Consts to let ui compare.
    consts: {
      unLoopModeValue: mdEventLoop.eventLoopMode.unLoop
    },
    today:util.formatDate(new Date(),'y年M月D日 星期w')
  },
  onSideSlipClosed: function(e) {
    this.setData({
      isSideSlipOpned: false
    })
  },
  onSidMenuTapped: function(e) {
    this.setData({
      isSideSlipOpned: true,
    })
  },
  
  //事件处理函数
  onShow: function() {
    this.refreshEventList();
  },
  refreshEventList:function(){
    this.setData({
      events: eventUtil.getEventList()
    });
  },

  onEventItemTapped: function(e) {
    var tappedEventItem = e.currentTarget.dataset.event;
    wx.navigateTo({
      url: '../detailView/detailView?detailId=' + JSON.stringify(tappedEventItem.id),
      fail: function(res) {
        wx.showToast({
          title: 'failed to open event details.',
        })
      }
    })
  },
  onEventItemLongTapped: function(e) {
    var eventItemTapped = e.currentTarget.dataset.event;
    if (!eventItemTapped)
      return;

    var currentPage = this;

    wx.showActionSheet({
      itemList: ['编辑', '删除'],
      success: function(res) {

        switch (res.tapIndex) {
          case 0:
            var editViewUrl_Prefix;
            var flatedEvent = util.flatObject(eventItemTapped);

            if (flatedEvent.typeId === mdEventType.eventType.date) {
              editViewUrl_Prefix = '../detailEdit_Date/detailEdit_Date?detail=';
            } 
            wx.navigateTo({
              url: editViewUrl_Prefix + JSON.stringify(flatedEvent),
              fail: function (res) {
                wx.showToast({
                  title: 'failed to open event details.',
                })
              }
            })
            break;
          case 1:
            wx.showModal({
              title: '删除确认',
              content: '确定要删除[' + eventItemTapped.title + ']?',
              success: function(e) {
                if (e.confirm) {
                  eventUtil.wipeEvent(eventItemTapped);
                  currentPage.refreshEventList();
                }
              }
            })
            break;
        }
      }
    });
  },

 
  onCreateDateEventTapped: function(e) {
    wx.navigateTo({
      url: '../detailEdit_Date/detailEdit_Date'
    });
  }
  
})