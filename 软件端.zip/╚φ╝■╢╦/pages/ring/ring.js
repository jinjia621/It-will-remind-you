// 在需要使用的js文件中，导入js  
var util = require('../../utils/util.js');
var app = getApp()
Page({
  data: {
    p: ''
  },


  onLoad: function () {
    wx.playBackgroundAudio({
      dataUrl: 'http://music.163.com/song/media/outer/url?id=139730.mp3',
    })
  },

  chaofeng2: function (e) {
    wx.pauseBackgroundAudio()
    var that = this;
    var times = 0
    var i = setInterval(function () {
      times++
      if (times >= 300) {
        wx.playBackgroundAudio({
          dataUrl: 'http://music.163.com/song/media/outer/url?id=19542337.mp3',
        })
        clearInterval(i)
      }
    }, 1000)
    wx.showToast({
      title: '宁可真能拖延',
      duration: 1000,
      icon: 'success'
    })
  },
  chaofeng3: function (e) {
    wx.pauseBackgroundAudio()
    var that = this;
    var times = 0
    var i = setInterval(function () {
      times++
      if (times >= 300) {
        wx.playBackgroundAudio({
          dataUrl: 'http://music.163.com/song/media/outer/url?id=26199445.mp3',
        })
        clearInterval(i)
      }
    }, 1000)
    wx.showToast({
      title: '宁可真能拖延',
      duration: 1000,
      icon: 'success'
    })
  },
  chaofeng4: function (e) {
    wx.pauseBackgroundAudio()
    var that = this;
    var times = 0
    var i = setInterval(function () {
      times++
      if (times >= 300) {
        wx.playBackgroundAudio({
          dataUrl: 'http://music.163.com/song/media/outer/url?id=1313107065.mp3',
        })
        clearInterval(i)
      }
    }, 1000)
    wx.showToast({
      title: '宁可真能拖延',
      duration: 1000,
      icon: 'success'
    })
  },
  chaofeng5: function (e) {
    wx.pauseBackgroundAudio()
    var that = this;
    var times = 0
    var i = setInterval(function () {
      times++
      if (times >= 300) {
        wx.playBackgroundAudio({
          dataUrl: 'http://music.163.com/song/media/outer/url?id=355992.mp3',
        })
        clearInterval(i)
      }
    }, 1000)
    wx.showToast({
      title: '宁可真能拖延',
      duration: 1000,
      icon: 'success'
    })
  },
  chaofeng: function (e) {
    wx.pauseBackgroundAudio()
    var that = this;
    var times = 0
    var i = setInterval(function () {
      times++
      if (times >= 300) {
        wx.playBackgroundAudio({
          dataUrl: 'http://music.163.com/song/media/outer/url?id=139730.mp3',
        })
        clearInterval(i)
      }
    }, 1000)
    wx.showToast({
      title: '宁可真能拖延',
      duration: 1000,
      icon: 'success'
    })
  },
  guli: function () {
    wx.pauseBackgroundAudio()
    wx.showToast({
      title: '享受现在吧',
      duration: 1000,
      icon: 'success'
    })
  },


  onShow: function () {
    var p = app.p;
    this.setData({
      p: p
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})